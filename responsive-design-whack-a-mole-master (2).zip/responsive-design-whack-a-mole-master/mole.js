// Write your JS here.
// window.addEventListener('DOMContentLoaded', () => {

//     setInterval(() => {
//       const moleHeads = document.querySelectorAll('.wgs__mole-head');
//       for (let moleHead of moleHeads) {
//         moleHead.classList.toggle('wgs__mole-head--hidden');
//       }
//     }, 1000);

//   });
function popUpRandomMole(){
    let moleHeads =document.querySelectorAll('.wgs__mole-head:not(.wgs__mole-head--whacked)');
    let rand = Math.floor(Math.random() * moleHeads.length);
    if(moleHeads.length === 0 ){
        alert('You Win Playa');
        return;
    }
    moleHeads[rand].classList.remove('wgs__mole-head--hidden');
    setTimeout(()=>{hideMole(moleHeads[rand])}, 3000);
};

function hideMole(mole){
    mole.classList.add('wgs__mole-head--hidden');
    setTimeout(popUpRandomMole,1000);
};
window.addEventListener('DOMContentLoaded',()=>{
    setTimeout(popUpRandomMole,0);
    let moleHeads = document.querySelectorAll('.wgs__mole-head');
    moleHeads.forEach((ele)=>{
        ele.addEventListener('click',(e)=>{
            e.target.classList.add('wgs__mole-head--hidden');
            e.target.classList.add('wgs__mole-head--whacked');
        })
    })
});
